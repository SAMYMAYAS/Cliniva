"""Lanceur Cliniva pour un poste client Windows, sans code applicatif serveur.

Le client affiche le serveur distant dans une fenêtre WebView locale. Le seul
code Cliniva installé sur le poste est ce lanceur ; les formulaires et données
restent servis par le serveur. Le pont local fournit le scanner et Office Word.
"""

from __future__ import annotations

import base64
import ctypes
import hashlib
import ipaddress
from io import BytesIO
import json
import os
import re
import shutil
import socket
import sys
import subprocess
import tempfile
import threading
import time
import urllib.error
import urllib.request
import uuid
import zipfile
from pathlib import Path
from tkinter import LEFT, X, Label, StringVar, Tk, messagebox
from tkinter.ttk import Button, Entry, Frame


APP_TITLE = "Cliniva — Poste client"
DEFAULT_PORT = 8000
CONFIG_PATH = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData/Local")) / "Cliniva" / "client_config.json"
DOCX_MIME = "data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64"
CLIENT_UPDATED_ON_START = False


def _secondary_monitor_bounds() -> tuple[int, int, int, int] | None:
    """Retourne les limites du second écran Windows, s'il existe."""
    if os.name != "nt":
        return None
    try:
        from ctypes import wintypes

        class Rect(ctypes.Structure):
            _fields_ = [(name, wintypes.LONG) for name in ("left", "top", "right", "bottom")]

        class MonitorInfo(ctypes.Structure):
            _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", Rect),
                        ("rcWork", Rect), ("dwFlags", wintypes.DWORD)]

        monitors = []
        callback_type = ctypes.WINFUNCTYPE(
            wintypes.BOOL, ctypes.c_void_p, ctypes.c_void_p, ctypes.POINTER(Rect), ctypes.c_ssize_t
        )

        def collect(handle, _dc, _rect, _data):
            info = MonitorInfo()
            info.cbSize = ctypes.sizeof(MonitorInfo)
            if ctypes.windll.user32.GetMonitorInfoW(handle, ctypes.byref(info)):
                rect = info.rcMonitor
                monitors.append((bool(info.dwFlags & 1), rect.left, rect.top, rect.right, rect.bottom))
            return True

        callback = callback_type(collect)
        if not ctypes.windll.user32.EnumDisplayMonitors(None, None, callback, 0):
            return None
        secondary = sorted((item for item in monitors if not item[0]), key=lambda item: (item[1], item[2]), reverse=True)
        if not secondary:
            return None
        _, left, top, right, bottom = secondary[0]
        return left, top, right - left, bottom - top
    except Exception:
        return None


def launch_service_tech_remote(system: str, host: str, username: str = "") -> dict:
    """Lance RDP ou SSH sur ce poste client Windows."""
    if os.name != "nt":
        return {"ok": False, "error": "Le lancement de RDP/SSH est configuré pour les postes Windows."}
    host = str(host or "").strip()
    username = str(username or "").strip()
    if not host:
        return {"ok": False, "error": "L'adresse IP ou le nom réseau de l'équipement est manquant."}
    try:
        address = ipaddress.ip_address(host)
        target_host = f"[{host}]" if address.version == 6 and system == "Windows" else host
    except ValueError:
        if not re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9.-]{0,251}[A-Za-z0-9])?", host):
            return {"ok": False, "error": "L'adresse réseau de l'équipement est invalide."}
        target_host = host
    if username and not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}", username):
        return {"ok": False, "error": "Le nom d'utilisateur ne peut pas être utilisé dans une commande SSH."}

    if system == "Windows":
        executable = shutil.which("mstsc.exe")
        if not executable:
            executable = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "mstsc.exe")
        if not os.path.isfile(executable):
            return {"ok": False, "error": "Le client Bureau à distance Windows (mstsc.exe) est introuvable."}
        subprocess.Popen([executable, f"/v:{target_host}"], close_fds=True)
        return {"ok": True}

    if system == "Linux":
        executable = shutil.which("ssh.exe") or shutil.which("ssh")
        if not executable:
            return {"ok": False, "error": "OpenSSH est introuvable sur ce poste. Installez le client OpenSSH Windows."}
        target = f"{username}@{host}" if username else host
        subprocess.Popen(
            [executable, target],
            creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0),
            close_fds=True,
        )
        return {"ok": True}
    return {"ok": False, "error": "Le système doit être Windows ou Linux."}


def normalize_server_url(value: str) -> str:
    value = value.strip().rstrip("/")
    if not value:
        raise ValueError("Saisis l'adresse IP ou le nom du PC serveur.")
    if "://" not in value:
        value = "http://" + value
    if not value.lower().startswith(("http://", "https://")):
        raise ValueError("L'adresse doit commencer par http:// ou https://.")
    authority = value.split("://", 1)[1].split("/", 1)[0]
    if not authority:
        raise ValueError("L'adresse du serveur est invalide.")
    if ":" not in authority and not authority.startswith("["):
        value = f"{value}:{DEFAULT_PORT}"
    return value


def load_server_url() -> str:
    try:
        data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        return normalize_server_url(str(data.get("server_url", "")))
    except (OSError, ValueError, json.JSONDecodeError, AttributeError):
        return ""


def save_server_url(server_url: str, client_version: str | None = None) -> None:
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    try:
        data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            data = {}
    except (OSError, ValueError, json.JSONDecodeError):
        data = {}
    data["server_url"] = server_url
    if client_version:
        data["client_version"] = client_version
    CONFIG_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")


def client_release_version() -> str:
    return hashlib.sha256(Path(__file__).read_bytes()).hexdigest()[:16]


def update_client_launcher(server_url: str, report_status=None) -> str | None:
    """Actualise uniquement ce fichier client.py; aucune source serveur n'est acceptée."""
    if report_status:
        report_status("Recherche d'une mise à jour sur le serveur…")
    manifest_url = server_url.rstrip("/") + "/static/client_updates/latest.json"
    request = urllib.request.Request(manifest_url, headers={"User-Agent": "ClinivaClient/2.0"})
    with urllib.request.urlopen(request, timeout=15) as response:
        manifest = json.loads(response.read(64 * 1024).decode("utf-8"))
    version = str(manifest.get("version") or "").strip()
    filename = str(manifest.get("filename") or "").strip()
    expected_hash = str(manifest.get("sha256") or "").strip().lower()
    package_url = str(manifest.get("package_url") or "")
    print_module = manifest.get("dicom_print_module") or {}
    module_hash = str(print_module.get("sha256") or "").strip().lower()
    module_url = str(print_module.get("package_url") or "")
    module_filename = str(print_module.get("filename") or "")
    if (not version or not filename or "/" in filename or "\\" in filename
            or len(expected_hash) != 64 or not package_url.startswith("/static/client_updates/")
            or ".." in package_url
            or manifest.get("contents") != ["client.py"]
            or not module_filename.startswith("client-dicom-print-")
            or not module_filename.endswith(".py") or "/" in module_filename or "\\" in module_filename
            or len(module_hash) != 64 or module_url != f"/static/client_updates/{module_filename}"):
        raise ValueError("Le serveur n'a pas publié une mise à jour client/DICOM Print valide.")
    # Compare le contenu réellement exécuté, pas seulement la version mémorisée
    # dans la configuration, afin qu'un ancien client ne saute pas la mise à jour.
    global CLIENT_UPDATED_ON_START
    current_version = client_release_version()
    module_path = Path(__file__).resolve().with_name("client_dicom_print.py")
    try:
        module_current_hash = hashlib.sha256(module_path.read_bytes()).hexdigest()
    except OSError:
        module_current_hash = ""
    if current_version == version and module_current_hash == module_hash:
        if report_status:
            report_status(f"Client et DICOM Print déjà à jour ({version}).")
        return version

    client_payload = None
    if current_version != version:
        if report_status:
            report_status(f"Mise à jour disponible ({version}) : téléchargement…")
        download_url = server_url.rstrip("/") + package_url
        request = urllib.request.Request(download_url, headers={"User-Agent": "ClinivaClient/2.0"})
        with urllib.request.urlopen(request, timeout=60) as response:
            client_payload = response.read(32 * 1024 * 1024 + 1)
        if len(client_payload) > 32 * 1024 * 1024 or hashlib.sha256(client_payload).hexdigest() != expected_hash:
            raise ValueError("La vérification de la mise à jour client a échoué.")

    module_payload = None
    if module_current_hash != module_hash:
        if report_status:
            report_status("Téléchargement du moteur DICOM Print du poste…")
        module_request = urllib.request.Request(
            server_url.rstrip("/") + module_url, headers={"User-Agent": "ClinivaClient/2.0"}
        )
        with urllib.request.urlopen(module_request, timeout=60) as response:
            module_payload = response.read(8 * 1024 * 1024 + 1)
        if len(module_payload) > 8 * 1024 * 1024 or hashlib.sha256(module_payload).hexdigest() != module_hash:
            raise ValueError("La vérification du moteur DICOM Print a échoué.")

    app_dir = Path(__file__).resolve().parent
    with tempfile.TemporaryDirectory(prefix="cliniva-client-update-", dir=app_dir) as staging_dir:
        if client_payload is not None:
            archive_path = Path(staging_dir) / filename
            archive_path.write_bytes(client_payload)
            with zipfile.ZipFile(archive_path) as archive:
                members = [item for item in archive.infolist() if not item.is_dir()]
                if len(members) != 1 or members[0].filename != "client.py":
                    raise ValueError("L'archive client contient autre chose que client.py.")
                client_source = archive.read(members[0])
            replacement = Path(staging_dir) / ".client.py.update"
            replacement.write_bytes(client_source)
            shutil.copystat(Path(__file__), replacement)
            os.replace(replacement, Path(__file__))
        if module_payload is not None:
            replacement_module = Path(staging_dir) / ".client_dicom_print.py.update"
            replacement_module.write_bytes(module_payload)
            os.replace(replacement_module, module_path)
        CLIENT_UPDATED_ON_START = True
    if report_status:
        report_status("Mise à jour installée avec succès. Redémarrage du client…")
    return version


def check_server(server_url: str) -> tuple[bool, str]:
    request = urllib.request.Request(
        server_url.rstrip("/") + "/api/app/health",
        headers={"User-Agent": "ClinivaClient/2.0"},
        method="GET",
    )
    try:
        with urllib.request.urlopen(request, timeout=6) as response:
            payload = json.loads(response.read(4096).decode("utf-8"))
            if response.status == 200 and payload.get("success") is True:
                return True, "Serveur Cliniva joignable."
            return False, "Le serveur répond, mais Cliniva signale qu'il n'est pas prêt."
    except urllib.error.HTTPError as exc:
        return False, f"Le serveur répond avec HTTP {exc.code}. Vérifie son état."
    except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
        return False, f"Serveur inaccessible : {getattr(exc, 'reason', exc)}"


def _safe_filename(value: str, fallback: str, extension: str) -> str:
    name = os.path.basename(str(value or fallback))
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip(" .") or fallback
    if not name.lower().endswith(extension):
        name += extension
    return name


class ClientHardwareBridge:
    """Fonctions strictement locales appelées par les pages du serveur Cliniva."""

    def __init__(self) -> None:
        self._zoom_percent = 100
        self._imaging_window = None
        self._imaging_base_url = ""
        self._imaging_loaded = False
        self._dicom_print_server = None
        self._dicom_print_a3_server = None
        self._dicom_print_lock = threading.RLock()
        self._word_sync_jobs: set[tuple[str, str, int]] = set()
        self._word_sync_states: dict[tuple[str, str, int], dict] = {}
        self._word_sync_lock = threading.Lock()

    def configure_imaging_window(self, window, base_url: str) -> None:
        self._imaging_window = window
        self._imaging_base_url = str(base_url or "").rstrip("/")

    def open_imaging_window(self) -> dict:
        window = self._imaging_window
        if window is None:
            return {"ok": False, "error": "La fenêtre secondaire n'est pas disponible."}
        try:
            if not self._imaging_loaded:
                window.load_url(f"{self._imaging_base_url}/?cliniva_screen=imaging")
                self._imaging_loaded = True
            window.show()
            return {"ok": True}
        except Exception as exc:
            self._imaging_loaded = False
            return {"ok": False, "error": str(exc)}

    def window_minimize(self, target: str = "main") -> None:
        """Réduit la fenêtre Cliniva du poste client."""
        import webview
        window = self._imaging_window if target == "imaging" else (webview.windows[0] if webview.windows else None)
        if window:
            window.minimize()

    def window_close(self, target: str = "main") -> None:
        """Ferme la fenêtre Cliniva du poste client."""
        import webview
        if target == "imaging" and self._imaging_window:
            self._imaging_window.hide()
            return
        if webview.windows:
            webview.windows[0].destroy()

    def service_tech_remote_access(self, system: str, host: str, username: str = "") -> dict:
        return launch_service_tech_remote(system, host, username)

    def _client_config(self) -> dict:
        try:
            data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError, json.JSONDecodeError):
            return {}

    def _save_dicom_print_config(self, values: dict) -> None:
        CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        data = self._client_config()
        data.update(values)
        temporary = CONFIG_PATH.with_suffix(".json.tmp")
        temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(temporary, CONFIG_PATH)

    def _dicom_print_service(self):
        if self._dicom_print_server is None:
            try:
                from client_dicom_print import DicomPrintServer
            except ImportError as exc:
                raise RuntimeError("Le moteur DICOM Print du poste manque. Relance le client connecté au serveur pour recevoir sa mise à jour.") from exc
            self._dicom_print_server = DicomPrintServer()
            saved = self._client_config().get("dicom_print_config")
            if isinstance(saved, dict):
                self._dicom_print_server._config.update(saved)
            self._dicom_print_server._config["auto_print_enabled"] = False
            self._dicom_print_server._config["auto_print_printer"] = ""
        return self._dicom_print_server

    def _dicom_print_a3_service(self):
        if self._dicom_print_a3_server is None:
            try:
                from client_dicom_print import DicomPrintServer
            except ImportError as exc:
                raise RuntimeError("Le moteur DICOM Print du poste manque. Relance le client connecté au serveur pour recevoir sa mise à jour.") from exc
            self._dicom_print_a3_server = DicomPrintServer()
            self._dicom_print_a3_server._config.update({
                "ae_title": "CLINIVA_A3_PRINT", "port": 11114,
                "storage_dir": str(Path.home() / "DicomPrints_A3"),
                "auto_print_enabled": False, "auto_print_printer": "", "auto_print_paper": "A3",
            })
            saved = self._client_config().get("dicom_print_a3_config")
            if isinstance(saved, dict):
                self._dicom_print_a3_server._config.update(saved)
        return self._dicom_print_a3_server

    def dicom_print_status(self) -> dict:
        with self._dicom_print_lock:
            try:
                state = self._dicom_print_service().status()
                return {**state, "machine": socket.gethostname()}
            except Exception as exc:
                return {
                    "running": False,
                    "config": {
                        "ae_title": "MY_PRINT_SCP", "host": "0.0.0.0", "port": 104,
                        "storage_dir": str(Path.home() / "DicomPrints"),
                    },
                    "last_error": str(exc),
                    "machine": socket.gethostname(),
                }

    def dicom_print_start(self, settings: dict | None = None) -> dict:
        try:
            with self._dicom_print_lock:
                safe_settings = dict(settings or {})
                safe_settings["auto_print_enabled"] = False
                safe_settings["auto_print_printer"] = ""
                state = self._dicom_print_service().start(safe_settings)
                self._save_dicom_print_config({"dicom_print_config": state["config"], "dicom_print_enabled": True})
            return {"ok": True, **state, "machine": socket.gethostname()}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def dicom_print_stop(self) -> dict:
        try:
            with self._dicom_print_lock:
                state = self._dicom_print_service().stop()
                self._save_dicom_print_config({"dicom_print_config": state["config"], "dicom_print_enabled": False})
            return {"ok": True, **state, "machine": socket.gethostname()}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def dicom_print_a3_status(self) -> dict:
        with self._dicom_print_lock:
            state = self._dicom_print_a3_service().status()
            return {**state, "machine": socket.gethostname()}

    def dicom_print_a3_jobs(self, limit: int = 100) -> list[dict]:
        try:
            with self._dicom_print_lock:
                return self._dicom_print_a3_service().recent_print_jobs(limit)
        except Exception:
            logger.exception("Impossible de lire l’historique d’impression DICOM A3")
            return []

    def dicom_print_a3_group_images(self, group_id: str) -> list[dict]:
        with self._dicom_print_lock:
            return self._dicom_print_a3_service().group_images(group_id)

    def dicom_print_a3_group_image(self, group_id: str, index: int) -> dict:
        with self._dicom_print_lock:
            return self._dicom_print_a3_service().group_image(group_id, index)

    def dicom_print_a3_group_image_pdf(self, group_id: str, index: int) -> dict:
        with self._dicom_print_lock:
            return self._dicom_print_a3_service().group_image_pdf(group_id, index)

    def dicom_print_a3_printers(self) -> list[dict]:
        try:
            with self._dicom_print_lock:
                return self._dicom_print_a3_service().available_printers()
        except Exception:
            return []

    def dicom_print_a3_save_config(self, settings: dict) -> dict:
        try:
            with self._dicom_print_lock:
                state = self._dicom_print_a3_service().configure_listener(settings)
                self._save_dicom_print_config({"dicom_print_a3_config": state["config"]})
            return {"ok": True, **state, "machine": socket.gethostname()}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def dicom_print_a3_configure_output(self, enabled: bool, printer_name: str = "") -> dict:
        try:
            with self._dicom_print_lock:
                state = self._dicom_print_a3_service().configure_auto_print(enabled, printer_name)
                self._save_dicom_print_config({"dicom_print_a3_config": state["config"]})
            return {"ok": True, **state, "machine": socket.gethostname()}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def dicom_print_a3_start(self) -> dict:
        try:
            with self._dicom_print_lock:
                state = self._dicom_print_a3_service().start()
                self._save_dicom_print_config({"dicom_print_a3_config": state["config"],
                                               "dicom_print_a3_enabled": True})
            return {"ok": True, **state, "machine": socket.gethostname()}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def dicom_print_a3_stop(self) -> dict:
        try:
            with self._dicom_print_lock:
                state = self._dicom_print_a3_service().stop()
                self._save_dicom_print_config({"dicom_print_a3_enabled": False})
            return {"ok": True, **state, "machine": socket.gethostname()}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def dicom_print_autostart(self) -> None:
        saved = self._client_config()
        if saved.get("dicom_print_enabled"):
            result = self.dicom_print_start(saved.get("dicom_print_config") or {})
            if not result.get("ok"):
                print(f"DICOM Print local non démarré : {result.get('error')}", file=sys.stderr)
        if saved.get("dicom_print_a3_enabled"):
            result = self.dicom_print_a3_start()
            if not result.get("ok"):
                print(f"Second DICOM Print A3 non démarré : {result.get('error')}", file=sys.stderr)

    def dicom_print_recent_images(self) -> list[dict]:
        with self._dicom_print_lock:
            return self._dicom_print_service().recent_images()

    def dicom_print_group_images(self, group_id: str) -> list[dict]:
        with self._dicom_print_lock:
            return self._dicom_print_service().group_images(group_id)

    def dicom_print_reorder_group_images(self, group_id: str, image_names: list[str]) -> dict:
        try:
            with self._dicom_print_lock:
                return self._dicom_print_service().reorder_group_images(group_id, image_names)
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def dicom_print_import_group_images(self, target_group_id: str, source_group_id: str,
                                        image_names: list[str]) -> dict:
        try:
            with self._dicom_print_lock:
                return self._dicom_print_service().import_group_images(target_group_id, source_group_id, image_names)
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def dicom_print_group_image(self, group_id: str, index: int) -> dict:
        with self._dicom_print_lock:
            return self._dicom_print_service().group_image(group_id, index)

    def dicom_print_group_thumbnail(self, group_id: str, index: int) -> dict:
        with self._dicom_print_lock:
            return self._dicom_print_service().group_image_thumbnail(group_id, index)

    def dicom_print_delete_group(self, group_id: str) -> dict:
        try:
            with self._dicom_print_lock:
                return self._dicom_print_service().delete_group(group_id)
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def dicom_print_merge_groups(self, target_group_id: str, source_group_ids: list[str]) -> dict:
        try:
            with self._dicom_print_lock:
                return self._dicom_print_service().merge_groups(target_group_id, source_group_ids)
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def dicom_print_group_image_pdf(self, group_id: str, index: int) -> dict:
        import base64
        import io
        from PIL import Image

        image_data = self.dicom_print_group_image(group_id, index)
        raw = base64.b64decode(image_data["data_url"].split(",", 1)[1])
        with Image.open(io.BytesIO(raw)) as source:
            page = Image.new("RGB", (3508, 4961), "white")
            image = source.convert("RGB")
            image.thumbnail((3388, 4841), Image.Resampling.LANCZOS)
            page.paste(image, ((3508 - image.width) // 2, (4961 - image.height) // 2))
            output = io.BytesIO()
            page.save(output, format="PDF", resolution=300.0)
        group = next((item for item in self.dicom_print_recent_images() if item.get("id") == group_id), {})
        return {"name": image_data["name"], "patient_name": group.get("patient_name", ""),
                "pdf_data_url": "data:application/pdf;base64," + base64.b64encode(output.getvalue()).decode("ascii")}

    def dicom_print_save_pdf(self, pdf_data_url: str, suggested_name: str = "Image_DICOM_A3.pdf",
                             target: str = "main") -> dict:
        import base64
        try:
            import webview
            dialog_window = self._imaging_window if target == "imaging" else (webview.windows[0] if webview.windows else None)
            if not dialog_window:
                return {"ok": False, "error": "La fenêtre Cliniva n’est pas prête à enregistrer le PDF."}
            header, separator, encoded = str(pdf_data_url or "").partition(",")
            if not separator or header.strip().lower() != "data:application/pdf;base64":
                return {"ok": False, "error": "Le contenu PDF à enregistrer est invalide."}
            content = base64.b64decode(encoded, validate=True)
            name = _safe_filename(suggested_name, "Image_DICOM_A3.pdf", ".pdf")
            dialog = getattr(webview, "FileDialog", None)
            selected = dialog_window.create_file_dialog(
                dialog.SAVE if dialog else webview.SAVE_DIALOG,
                save_filename=name, file_types=("Fichiers PDF (*.pdf)",),
            )
            if not selected:
                return {"ok": True, "cancelled": True}
            target = Path(selected[0] if isinstance(selected, (list, tuple)) else selected)
            if target.suffix.lower() != ".pdf":
                target = target.with_suffix(".pdf")
            target.write_bytes(content)
            return {"ok": True, "path": str(target)}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def dicom_print_open_folder(self) -> dict:
        try:
            folder = self._dicom_print_service().status()["config"]["storage_dir"]
            Path(folder).mkdir(parents=True, exist_ok=True)
            if sys.platform == "win32":
                os.startfile(folder)
            else:
                return {"ok": False, "error": "L’ouverture du dossier nécessite Windows."}
            return {"ok": True}
        except Exception as exc:
            return {"ok": False, "error": f"Impossible d’ouvrir le dossier local : {exc}"}

    @staticmethod
    def _word_sync_key(path: Path, document_kind: str, record_id: int) -> tuple[str, str, int]:
        return (str(path.resolve()).casefold(), str(document_kind), int(record_id))

    def client_word_sync_status(self, document_kind: str, record_id: int) -> dict:
        """Expose l'état de la dernière synchronisation Word au navigateur Cliniva."""
        with self._word_sync_lock:
            matches = [state for key, state in self._word_sync_states.items()
                       if key[1] == str(document_kind) and key[2] == int(record_id)]
            return dict(matches[-1]) if matches else {"status": "waiting", "message": "En attente d'une sauvegarde Word."}

    @staticmethod
    def _valid_docx_bytes(content: bytes) -> bool:
        try:
            with zipfile.ZipFile(BytesIO(content)) as document:
                names = set(document.namelist())
                return "[Content_Types].xml" in names and "word/document.xml" in names
        except (OSError, zipfile.BadZipFile):
            return False

    def _upload_word_document(self, server_url: str, document_kind: str,
                              record_id: int, path: Path, sync_token: str | None = None) -> None:
        """Envoie au serveur une version Word stable enregistrée depuis le client."""
        content = path.read_bytes()
        if not content or len(content) > 100 * 1024 * 1024 or not self._valid_docx_bytes(content):
            raise ValueError("Le fichier local n'est pas encore un document DOCX enregistré et valide.")

        routes = {
            "template": f"/api/cr-templates/upload-word/{int(record_id)}",
            "dme_cr": f"/api/dme/cr/upload-word/{int(record_id)}",
        }
        route = routes.get(str(document_kind or "template"))
        if not route:
            raise ValueError("Type de document à synchroniser non autorisé.")
        if document_kind == "dme_cr" and not sync_token:
            raise ValueError("Autorisation de synchronisation absente. Rouvrez le compte rendu depuis le DME.")
        boundary = "----ClinivaWordSync" + uuid.uuid4().hex
        head = (
            f"--{boundary}\r\n"
            'Content-Disposition: form-data; name="file"; filename="modele_compte_rendu.docx"\r\n'
            "Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document\r\n\r\n"
        ).encode("ascii")
        body = head + content + f"\r\n--{boundary}--\r\n".encode("ascii")
        request = urllib.request.Request(
            f"{server_url.rstrip('/')}{route}",
            data=body,
            headers={
                "Content-Type": f"multipart/form-data; boundary={boundary}",
                "Content-Length": str(len(body)),
                "User-Agent": "ClinivaClient/2.0",
                **({"X-Cliniva-CR-Sync-Token": sync_token} if document_kind == "dme_cr" else {}),
            },
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=90) as response:
            result = json.loads(response.read(16 * 1024).decode("utf-8"))
        if response.status != 200 or result.get("success") is not True:
            raise RuntimeError(result.get("detail") or result.get("message") or "Le serveur a refusé la synchronisation du modèle.")

    def _watch_word_document(self, path: Path, server_url: str,
                             document_kind: str, record_id: int, sync_token: str | None = None) -> None:
        """Synchronise automatiquement chaque sauvegarde Word après stabilisation du fichier."""
        try:
            initial = path.stat()
            previous_signature = (initial.st_mtime_ns, initial.st_size)
        except OSError:
            return

        pending_since = None
        last_attempt = 0.0
        while path.exists():
            time.sleep(1.0)
            try:
                current = path.stat()
                signature = (current.st_mtime_ns, current.st_size)
            except OSError:
                continue

            now = time.monotonic()
            if signature != previous_signature:
                previous_signature = signature
                pending_since = now
                last_attempt = 0.0
                with self._word_sync_lock:
                    self._word_sync_states[self._word_sync_key(path, document_kind, record_id)] = {
                        "status": "changed", "message": "Modification détectée, attente de la fin de l'enregistrement Word."
                    }
                continue
            if pending_since is None or now - pending_since < 1.5 or now - last_attempt < 5.0:
                continue

            last_attempt = now
            key = self._word_sync_key(path, document_kind, record_id)
            with self._word_sync_lock:
                self._word_sync_states[key] = {"status": "uploading", "message": "Envoi du compte rendu vers le serveur…"}
            try:
                self._upload_word_document(server_url, document_kind, record_id, path, sync_token)
                pending_since = None
                with self._word_sync_lock:
                    self._word_sync_states[key] = {
                        "status": "synced", "message": "Compte rendu enregistré sur le serveur.", "synced_at": int(time.time())
                    }
            except Exception as exc:
                # Word peut encore verrouiller le fichier ou le réseau être
                # momentanément indisponible : un nouvel essai sera fait.
                with self._word_sync_lock:
                    self._word_sync_states[key] = {"status": "retrying", "message": str(exc) or "Échec de synchronisation."}
                continue

    def _start_word_document_sync(self, path: Path, document_kind: str, record_id: int,
                                  sync_token: str | None = None) -> bool:
        server_url = load_server_url()
        if not server_url or not record_id or document_kind not in {"template", "dme_cr"}:
            return False
        key = self._word_sync_key(path, document_kind, record_id)
        with self._word_sync_lock:
            if key in self._word_sync_jobs:
                return True
            self._word_sync_jobs.add(key)
            self._word_sync_states[key] = {"status": "watching", "message": "En attente d'une sauvegarde dans Word."}
        threading.Thread(
            target=self._watch_word_document,
            args=(path, server_url, str(document_kind), int(record_id), sync_token),
            name=f"ClinivaWordSync-{document_kind}-{int(record_id)}",
            daemon=True,
        ).start()
        return True

    def client_scanner_detect(self) -> dict:
        if sys.platform != "win32":
            return {"success": False, "scanners": [], "message": "Le scan matériel est disponible sur Windows."}
        pythoncom = None
        try:
            import pythoncom as com
            import win32com.client
            pythoncom = com
            pythoncom.CoInitialize()
            manager = win32com.client.Dispatch("WIA.DeviceManager")
            devices = []
            for info in manager.DeviceInfos:
                try:
                    devices.append({"id": str(info.DeviceID), "name": str(info.Properties("Name").Value or "Scanner WIA")})
                except Exception:
                    continue
            return {"success": True, "scanners": devices,
                    "message": "Scanner(s) détecté(s) sur ce poste." if devices else "Aucun scanner WIA détecté sur ce poste."}
        except Exception as exc:
            return {"success": False, "scanners": [], "message": f"WIA/pywin32 indisponible : {exc}"}
        finally:
            if pythoncom:
                try:
                    pythoncom.CoUninitialize()
                except Exception:
                    pass

    def client_scanner_acquire(self, device_id: str = "") -> dict:
        if sys.platform != "win32":
            return {"success": False, "message": "Le scan matériel est disponible sur Windows."}
        pythoncom = None
        temporary_path = None
        try:
            import pythoncom as com
            import win32com.client
            pythoncom = com
            pythoncom.CoInitialize()
            manager = win32com.client.Dispatch("WIA.DeviceManager")
            info = next((item for item in manager.DeviceInfos if str(item.DeviceID) == str(device_id)), None)
            if info is None:
                return {"success": False, "message": "Le scanner sélectionné n'est plus disponible."}
            device = info.Connect()
            if device.Items.Count < 1:
                return {"success": False, "message": "Le scanner ne contient aucun élément de numérisation."}
            item = device.Items.Item(1)
            # 3CAB = BMP (non compressé) ; le vrai identifiant WIA JPEG est 3CAE.
            jpeg_format = "{B96B3CAE-0728-11D3-9D7B-0000F81EF32E}"
            try:
                # Préférence facultative : couleur avec une taille de fichier réduite.
                item.Properties("Current Intent").Value = 0x00010001
            except Exception:
                pass
            image = None
            transfer_error = None
            try:
                image = item.Transfer(jpeg_format)
            except Exception as exc:
                transfer_error = exc

            # Certains pilotes WIA renvoient None pour Item.Transfer, même si le
            # scanner est présent. Le CommonDialog gère leur transfert avec la
            # boîte de progression native Windows et retourne l'ImageFile.
            if image is None:
                try:
                    common_dialog = win32com.client.Dispatch("WIA.CommonDialog")
                    image = common_dialog.ShowTransfer(item, jpeg_format, False)
                except Exception as exc:
                    transfer_error = exc
            if image is None:
                detail = f" ({transfer_error})" if transfer_error else ""
                return {"success": False, "message":
                        "Le pilote WIA n'a fourni aucune image. Vérifie le pilote du scanner et réessaie." + detail}

            # Lire le vecteur d'octets WIA évite les pilotes qui échouent à
            # créer le fichier demandé par ImageFile.SaveFile.
            try:
                content = bytes(image.FileData.BinaryData)
            except Exception:
                # Certains pilotes exposent mal FileData.BinaryData ; le chemin
                # fichier reste disponible en secours avec un nom neuf.
                temporary_path = str(Path(tempfile.gettempdir()) / f"cliniva_scan_{uuid.uuid4().hex}.jpg")
                save_image = getattr(image, "SaveFile", None)
                if not callable(save_image):
                    return {"success": False, "message":
                            "Le pilote a terminé le scan sans fournir les octets de l'image. "
                            "Vérifie le pilote WIA du scanner."}
                save_image(temporary_path)
                if not os.path.isfile(temporary_path):
                    return {"success": False, "message": "Le pilote n'a pas fourni de données image exploitables."}
                content = Path(temporary_path).read_bytes()

            max_bytes = 12 * 1024 * 1024
            image_is_jpeg = str(getattr(image, "FormatID", "")).strip().upper() == jpeg_format.upper()
            if content and (not image_is_jpeg or len(content) > max_bytes):
                # Certains pilotes ignorent le format demandé ou livrent un BMP.
                # Conversion + réduction WIA gardent le document lisible et
                # respectent la limite acceptée par le formulaire serveur.
                last_candidate = b""
                for max_width, max_height, quality in ((2600, 3400, 82), (2200, 3000, 72), (1800, 2500, 60)):
                    try:
                        processor = win32com.client.Dispatch("WIA.ImageProcess")
                        processor.Filters.Add(processor.FilterInfos("Scale").FilterID)
                        scale_filter = processor.Filters.Item(1)
                        scale_filter.Properties("MaximumWidth").Value = max_width
                        scale_filter.Properties("MaximumHeight").Value = max_height
                        processor.Filters.Add(processor.FilterInfos("Convert").FilterID)
                        convert_filter = processor.Filters.Item(2)
                        convert_filter.Properties("FormatID").Value = jpeg_format
                        convert_filter.Properties("Quality").Value = quality
                        converted = processor.Apply(image)
                        last_candidate = bytes(converted.FileData.BinaryData)
                        if last_candidate and len(last_candidate) <= max_bytes:
                            content = last_candidate
                            break
                    except Exception:
                        continue
                else:
                    if last_candidate:
                        content = last_candidate

            if not content:
                return {"success": False, "message": "Le scanner a retourné une image vide. Vérifie le pilote WIA."}
            if len(content) > max_bytes:
                size_mb = len(content) / (1024 * 1024)
                return {"success": False, "message":
                        f"Le scan fait encore {size_mb:.1f} Mo après compression. "
                        "Choisis une résolution de 200 dpi ou moins dans les paramètres du scanner."}
            return {"success": True, "image_data": "data:image/jpeg;base64," + base64.b64encode(content).decode("ascii"),
                    "name": Path(temporary_path).name if temporary_path else f"cliniva_scan_{uuid.uuid4().hex}.jpg"}
        except Exception as exc:
            return {"success": False, "message": f"Le scanner n'a pas pu numériser le document : {exc}"}
        finally:
            if temporary_path:
                try:
                    os.unlink(temporary_path)
                except OSError:
                    pass
            if pythoncom:
                try:
                    pythoncom.CoUninitialize()
                except Exception:
                    pass

    def client_open_word_document(self, docx_data_url: str, suggested_name: str = "Compte_rendu.docx",
                                  template_id: int | None = None, sync_kind: str = "template",
                                  sync_token: str | None = None) -> dict:
        try:
            if sys.platform != "win32":
                return {"ok": False, "error": "L'ouverture dans Microsoft Word nécessite Windows."}
            header, separator, encoded = str(docx_data_url or "").partition(",")
            if not separator or header.strip().lower() != DOCX_MIME:
                return {"ok": False, "error": "Le document Word reçu est invalide."}
            content = base64.b64decode(encoded, validate=True)
            if not content or len(content) > 100 * 1024 * 1024:
                return {"ok": False, "error": "Le document est vide ou dépasse 100 Mo."}
            filename = _safe_filename(suggested_name, "Compte_rendu.docx", ".docx")
            folder = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData/Local")) / "Cliniva" / "Documents"
            folder.mkdir(parents=True, exist_ok=True)
            target = folder / filename
            if target.exists():
                target = folder / f"{target.stem}_{int(time.time())}{target.suffix}"
            target.write_bytes(content)
            os.startfile(str(target))
            sync_started = self._start_word_document_sync(target, str(sync_kind), int(template_id), sync_token) if template_id else False
            return {"ok": True, "path": str(target), "sync_started": sync_started}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def kacel_job_save_and_open_docx(self, docx_data_url: str, suggested_name: str = "Convention.docx") -> dict:
        try:
            import webview
            if sys.platform != "win32" or not webview.windows:
                return {"ok": False, "error": "La fenêtre cliente Windows n'est pas prête."}
            header, separator, encoded = str(docx_data_url or "").partition(",")
            if not separator or header.strip().lower() != DOCX_MIME:
                return {"ok": False, "error": "Le document Word reçu est invalide."}
            content = base64.b64decode(encoded, validate=True)
            if not content or len(content) > 100 * 1024 * 1024:
                return {"ok": False, "error": "Le document est vide ou dépasse 100 Mo."}
            filename = _safe_filename(suggested_name, "Convention.docx", ".docx")
            selected = webview.windows[0].create_file_dialog(
                webview.FileDialog.SAVE, save_filename=filename, file_types=("Document Word (*.docx)",)
            )
            if not selected:
                return {"ok": True, "cancelled": True}
            target = Path(selected[0] if isinstance(selected, (list, tuple)) else selected)
            if target.suffix.lower() != ".docx":
                target = target.with_suffix(".docx")
            target.write_bytes(content)
            os.startfile(str(target))
            return {"ok": True, "path": str(target)}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def print_server_open_pdf(self, pdf_data_url: str, suggested_name: str = "Livret.pdf") -> dict:
        try:
            if sys.platform != "win32":
                return {"ok": False, "error": "L'ouverture avec le lecteur PDF nécessite Windows."}
            header, separator, encoded = str(pdf_data_url or "").partition(",")
            if not separator or header.strip().lower() != "data:application/pdf;base64":
                return {"ok": False, "error": "Le fichier PDF reçu est invalide."}
            content = base64.b64decode(encoded, validate=True)
            if not content or len(content) > 200 * 1024 * 1024:
                return {"ok": False, "error": "Le PDF est vide ou dépasse 200 Mo."}
            stem = Path(str(suggested_name or "Livret.pdf")).stem
            stem = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", stem).strip(" .") or "Livret"
            folder = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData/Local")) / "Cliniva" / "Documents"
            folder.mkdir(parents=True, exist_ok=True)
            target = folder / f"{stem}_{int(time.time())}.pdf"
            target.write_bytes(content)
            os.startfile(str(target))
            return {"ok": True, "path": str(target)}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def interface_zoom(self, action="status", value=None) -> dict:
        if action == "in":
            self._zoom_percent = min(300, self._zoom_percent + 10)
        elif action == "out":
            self._zoom_percent = max(50, self._zoom_percent - 10)
        elif action == "reset":
            self._zoom_percent = 100
        elif action == "set":
            try:
                self._zoom_percent = max(50, min(300, int(value)))
            except (TypeError, ValueError):
                return {"ok": False, "error": "Pourcentage de zoom invalide."}
        elif action != "status":
            return {"ok": False, "error": "Commande de zoom invalide."}
        try:
            import webview
            if webview.windows:
                webview.windows[0].evaluate_js(f"document.documentElement.style.zoom='{self._zoom_percent}%'"
                                               f";document.body.style.zoom='{self._zoom_percent}%' ")
        except Exception:
            pass
        return {"ok": True, "percent": self._zoom_percent}


def open_client_window(server_url: str) -> None:
    try:
        import webview
    except ImportError as exc:
        raise RuntimeError(
            "Le composant de fenêtre cliente manque. Installe-le une fois sur ce PC avec :\n"
            "py -m pip install pywebview pywin32\n\n"
            "Le code Cliniva du serveur n'est pas nécessaire sur le poste client."
        ) from exc
    bridge = ClientHardwareBridge()
    bridge.dicom_print_autostart()
    window = webview.create_window(
        "Cliniva", server_url, width=1440, height=940, min_size=(900, 650),
        resizable=True, zoomable=True, fullscreen=True, js_api=bridge,
    )
    monitor = _secondary_monitor_bounds()
    if monitor:
        monitor_x, monitor_y, monitor_width, monitor_height = monitor
        imaging_x, imaging_y = monitor_x + 16, monitor_y + 16
        imaging_width, imaging_height = max(900, monitor_width - 32), max(650, monitor_height - 64)
    else:
        imaging_x, imaging_y, imaging_width, imaging_height = 80, 80, 1280, 820
    imaging_window = webview.create_window(
        "Cliniva — Imagerie", "about:blank", x=imaging_x, y=imaging_y,
        width=imaging_width, height=imaging_height, min_size=(900, 650),
        resizable=True, zoomable=True, hidden=True, js_api=bridge,
    )
    bridge.configure_imaging_window(imaging_window, server_url)

    def install_window_controls(target_window) -> None:
        target_window.evaluate_js("""(() => {
          const install = () => {
            if (document.getElementById('cliniva-window-controls')) return;
            if (!document.getElementById('cliniva-window-controls-style')) {
              const style = document.createElement('style');
              style.id = 'cliniva-window-controls-style';
              style.textContent = `
                #cliniva-window-controls { opacity:0; transform:translateY(-6px); transition:opacity .18s ease, transform .18s ease; }
                #cliniva-window-controls:hover, #cliniva-window-controls:focus-within { opacity:1; transform:translateY(0); }
                #cliniva-window-controls button { transition: background .16s ease, color .16s ease, transform .16s ease, box-shadow .16s ease; }
                #cliniva-window-controls button:hover { transform: translateY(-1px); box-shadow: 0 2px 7px rgba(24,55,43,.16); }
                #cliniva-window-controls .cliniva-minimize:hover { background:#e7f3ed !important; color:#176b4d !important; }
                #cliniva-window-controls .cliniva-close:hover { background:#d94450 !important; color:#fff !important; }
                #cliniva-window-controls button:focus-visible { outline:2px solid #16845e; outline-offset:2px; }
              `;
              document.head.appendChild(style);
            }
            const bar = document.createElement('div');
            bar.id = 'cliniva-window-controls';
            bar.setAttribute('role', 'group');
            bar.setAttribute('aria-label', 'Commandes de la fenêtre');
            bar.style.cssText = 'position:fixed;top:12px;right:14px;z-index:2147483647;display:flex;gap:4px;padding:4px;background:rgba(255,255,255,.97);border:1px solid #dce7e1;border-radius:11px;box-shadow:0 4px 14px rgba(26,55,43,.14);backdrop-filter:blur(8px)';
            const makeButton = (label, icon, className, action) => {
              const button = document.createElement('button');
              button.type = 'button'; button.title = label; button.setAttribute('aria-label', label); button.className = className;
              button.innerHTML = icon;
              button.style.cssText = `width:34px;height:32px;border:0;border-radius:8px;background:${className === 'cliniva-close' ? '#fff0f0' : '#f1f6f3'};color:${className === 'cliniva-close' ? '#c43e49' : '#527064'};cursor:pointer;display:grid;place-items:center;padding:0`;
              button.addEventListener('click', event => { event.preventDefault(); event.stopPropagation(); const target = new URLSearchParams(window.location.search).get('cliniva_screen') === 'imaging' ? 'imaging' : 'main'; window.pywebview.api[action](target); });
              bar.appendChild(button);
            };
            makeButton('Réduire', '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 12h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>', 'cliniva-minimize', 'window_minimize');
            makeButton('Fermer', '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m7 7 10 10M17 7 7 17" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>', 'cliniva-close', 'window_close');
            document.body.appendChild(bar);
          };
          install();
          new MutationObserver(install).observe(document.documentElement, {childList:true, subtree:true});
        })()""")

    window.events.loaded += lambda: install_window_controls(window)
    imaging_window.events.loaded += lambda: install_window_controls(imaging_window)
    webview.start(debug=False)


class ClinivaClient:
    def __init__(self) -> None:
        self.root = Tk()
        self.root.title(APP_TITLE)
        self.root.geometry("600x285")
        self.root.minsize(520, 260)
        self.root.configure(bg="#f3f6f5")
        Label(self.root, text="Connexion au serveur Cliniva", font=("Segoe UI", 17, "bold"),
              fg="#153c2c", bg="#f3f6f5").pack(anchor="w", padx=24, pady=(22, 4))
        Label(self.root, text="Les pages restent sur le serveur. Ce poste utilise seulement le lanceur et ses périphériques locaux.",
              font=("Segoe UI", 10), fg="#58665f", bg="#f3f6f5", wraplength=530, justify=LEFT
              ).pack(anchor="w", padx=24, pady=(0, 14))
        self.server_var = StringVar(value=load_server_url())
        self.entry = Entry(self.root, textvariable=self.server_var, font=("Segoe UI", 11))
        self.entry.pack(fill=X, padx=24, ipady=7)
        self.entry.bind("<Return>", lambda _event: self.connect())
        self.status_var = StringVar(value="Le port 8000 est ajouté automatiquement si nécessaire.")
        self.status_label = Label(self.root, textvariable=self.status_var, font=("Segoe UI", 9), fg="#58665f",
                                  bg="#f3f6f5", wraplength=510, justify=LEFT)
        self.status_label.pack(anchor="w", padx=24, pady=12)
        buttons = Frame(self.root)
        buttons.pack(fill=X, padx=24, pady=(2, 18))
        self.connect_button = Button(buttons, text="Se connecter à Cliniva", command=self.connect)
        self.connect_button.pack(side=LEFT)
        Button(buttons, text="Quitter", command=self.root.destroy).pack(side=LEFT, padx=(10, 0))
        self.root.mainloop()

    def connect(self) -> None:
        try:
            server_url = normalize_server_url(self.server_var.get())
        except ValueError as exc:
            messagebox.showerror(APP_TITLE, str(exc), parent=self.root)
            return
        self.status_var.set("Vérification du serveur…")
        self.status_label.configure(fg="#58665f")
        self.connect_button.state(["disabled"])
        self.root.update_idletasks()
        threading.Thread(target=self._check_and_open, args=(server_url,), daemon=True).start()

    def _check_and_open(self, server_url: str) -> None:
        reachable, message = check_server(server_url)
        if not reachable:
            self.root.after(0, self._show_error, message)
            return
        try:
            save_server_url(server_url)
        except OSError as exc:
            self.root.after(0, self._show_error, f"Impossible d'enregistrer l'adresse du serveur : {exc}")
            return
        self.root.after(0, self._begin_update, server_url)

    def _set_status(self, message: str, color: str = "#58665f") -> None:
        try:
            self.status_var.set(message)
            self.status_label.configure(fg=color)
            self.root.update_idletasks()
        except Exception:
            pass

    def _begin_update(self, server_url: str) -> None:
        self._set_status("Connexion établie. Recherche d'une mise à jour…", "#2563eb")
        threading.Thread(target=self._update_and_open, args=(server_url,), daemon=True).start()

    def _update_and_open(self, server_url: str) -> None:
        update_error = None
        version = None
        try:
            version = update_client_launcher(
                server_url,
                report_status=lambda message: self.root.after(0, self._set_status, message, "#2563eb"),
            )
            save_server_url(server_url, version)
        except Exception as exc:
            update_error = str(exc)
        self.root.after(0, self._finish_update, server_url, version, update_error)

    def _finish_update(self, server_url: str, version: str | None, update_error: str | None) -> None:
        if update_error:
            self._set_status(f"Échec de la mise à jour : {update_error}", "#b91c1c")
            messagebox.showwarning(
                APP_TITLE,
                "La mise à jour du client a échoué. La version installée sera lancée.\n\n"
                f"Détail : {update_error}\n\n"
                "Vérifie que le serveur a été redémarré et que le dossier du client est accessible en écriture.",
                parent=self.root,
            )
            self.root.after(100, self._open_webview, server_url)
            return
        if CLIENT_UPDATED_ON_START:
            self._set_status(f"Mise à jour réussie ({version}). Redémarrage du client…", "#15803d")
            self.root.after(1000, self._restart_updated_client, server_url)
            return
        self._set_status(f"Aucune mise à jour nécessaire : client à jour ({version}).", "#15803d")
        self.root.after(900, self._open_webview, server_url)

    def _restart_updated_client(self, server_url: str) -> None:
        try:
            subprocess.Popen(
                [sys.executable, str(Path(__file__).resolve()), server_url],
                cwd=str(Path(__file__).resolve().parent),
            )
            self.root.destroy()
        except Exception as exc:
            self._set_status(f"Mise à jour faite, mais redémarrage impossible : {exc}", "#b91c1c")
            self.connect_button.state(["!disabled"])

    def _open_webview(self, server_url: str) -> None:
        self.root.destroy()
        try:
            open_client_window(server_url)
        except Exception as exc:
            fallback = Tk()
            fallback.withdraw()
            messagebox.showerror(APP_TITLE, str(exc), parent=fallback)
            fallback.destroy()

    def _show_error(self, message: str) -> None:
        self._set_status(message, "#b91c1c")
        self.connect_button.state(["!disabled"])
        messagebox.showerror(APP_TITLE, message + "\n\nVérifie que le serveur est lancé et que le port 8000 est autorisé sur le réseau.", parent=self.root)

def main() -> int:
    if len(sys.argv) > 1:
        try:
            server_url = normalize_server_url(sys.argv[1])
        except ValueError as exc:
            print(f"Erreur : {exc}", file=sys.stderr)
            return 2
        reachable, message = check_server(server_url)
        print(message)
        if not reachable:
            return 1
        try:
            save_server_url(server_url)
            try:
                version = update_client_launcher(server_url)
                save_server_url(server_url, version)
                if CLIENT_UPDATED_ON_START:
                    subprocess.Popen(
                        [sys.executable, str(Path(__file__).resolve()), server_url],
                        cwd=str(Path(__file__).resolve().parent),
                    )
                    return 0
            except Exception:
                pass
            open_client_window(server_url)
        except Exception as exc:
            print(str(exc), file=sys.stderr)
            return 1
        return 0
    ClinivaClient()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
